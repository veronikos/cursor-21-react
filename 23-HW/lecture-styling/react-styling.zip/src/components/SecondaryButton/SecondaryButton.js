import "./SecondaryButton.css";

const SecondaryButton = () => {
  return <button className="SecondaryButton__button">Secondary</button>;
};

export default SecondaryButton;
