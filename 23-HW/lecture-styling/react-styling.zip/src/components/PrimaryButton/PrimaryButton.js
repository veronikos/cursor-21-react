import React from "react";
import "./PrimaryButton.css";

const PrimaryButton = () => {
  return <button className="button">Primary</button>;
};

export default PrimaryButton;
